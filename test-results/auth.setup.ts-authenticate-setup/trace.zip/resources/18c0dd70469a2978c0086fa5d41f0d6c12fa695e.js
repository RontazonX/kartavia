import{d as s}from"../chunks/BE6iRtjL.js";import{x as t}from"../chunks/BPLAjmJi.js";export{t as load_css,s as start};
