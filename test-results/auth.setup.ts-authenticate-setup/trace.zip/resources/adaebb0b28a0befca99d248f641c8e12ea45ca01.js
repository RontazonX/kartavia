const e=globalThis.__sveltekit_u09cwk.env;export{e};
