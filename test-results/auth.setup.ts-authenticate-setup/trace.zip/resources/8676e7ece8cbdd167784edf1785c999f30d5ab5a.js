import{ak as a}from"./6etiCmbR.js";a();
